#!/usr/bin/env python
# coding: utf-8

# In[1]:


#MSC-7103 MACHINE LEARNING PROJECT
#LIFE EXPECTANCY PREDICTION 
# MAGALA MUHUSINU 2025/HD05/26352U 
# Import Required Libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Setting visualization style
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (12, 6)

print("Most of the Libraries imported successfully")


# In[2]:


url = 'https://drive.google.com/uc?id=1YOaRUnGwRIjIRxlAfjwUyLXCU3xU1Pda'
df = pd.read_csv(url)


# In[6]:


print("=" * 80)
print("DATASET LOADING SUMMARY")
print("=" * 80)
print(f"\nDataset shape: {df.shape[0]} rows × {df.shape[1]} columns")
print(f"\nFirst few rows:")
print(df.head(10))


# In[7]:


# Dataset Information
print("\n" + "=" * 80)
print("DATA TYPES AND COLUMN INFORMATION")
print("=" * 80)
print(df.info())

print("\n" + "=" * 80)
print("COLUMN NAMES AND DTYPES")
print("=" * 80)
for i, (col, dtype) in enumerate(zip(df.columns, df.dtypes), 1):
    print(f"{i:2d}. {col:30s} - {dtype}")


# In[8]:


# Missing Values Analysis
print("\n" + "=" * 80)
print("MISSING VALUES ANALYSIS")
print("=" * 80)

missing_values = df.isnull().sum()
missing_percent = (missing_values / len(df)) * 100
missing_df = pd.DataFrame({
    'Column': missing_values.index,
    'Missing_Count': missing_values.values,
    'Missing_Percent': missing_percent.values
})
missing_df = missing_df[missing_df['Missing_Count'] > 0].sort_values('Missing_Count', ascending=False)

if len(missing_df) > 0:
    print(missing_df.to_string())
else:
    print("✓ No missing values found!")

# Duplicates
print(f"\n✓ Duplicate rows: {df.duplicated().sum()}")

# Basic statistics
print("\n" + "=" * 80)
print("BASIC STATISTICS")
print("=" * 80)
print(df.describe())


# In[3]:


#Exploratory Data analysis
# Categorical vs Numerical Features
print("=" * 80)
print("FEATURE TYPE ANALYSIS")
print("=" * 80)

categorical_cols = df.select_dtypes(include='object').columns.tolist()
numerical_cols = df.select_dtypes(include=['int64', 'float64']).columns.tolist()

print(f"\n📊 Categorical Columns ({len(categorical_cols)}):")
for col in categorical_cols:
    print(f"   • {col}: {df[col].nunique()} unique values")
    print(f"     Sample: {df[col].unique()[:5]}")

print(f"\n🔢 Numerical Columns ({len(numerical_cols)}):")
for col in numerical_cols:
    print(f"   • {col}")

# Target variable analysis
target = 'Life expectancy '
print(f"\n" + "=" * 80)
print(f"TARGET VARIABLE: {target}")
print("=" * 80)
print(f"Mean: {df[target].mean():.2f}")
print(f"Median: {df[target].median():.2f}")
print(f"Std Dev: {df[target].std():.2f}")
print(f"Min: {df[target].min():.2f}")
print(f"Max: {df[target].max():.2f}")
print(f"Missing: {df[target].isnull().sum()}")


# In[10]:


# Country and Status distribution
print("\n" + "=" * 80)
print("COUNTRY AND STATUS DISTRIBUTION")
print("=" * 80)

print(f"\nUnique Countries: {df['Country'].nunique()}")
print(f"Countries: {df['Country'].unique()[:10]}...")

print(f"\nStatus Distribution:")
print(df['Status'].value_counts())

print(f"\nYear Range: {df['Year'].min()} - {df['Year'].max()}")
print(f"Total observations: {len(df)}")
print(f"Countries × Years: {df['Country'].nunique()} countries × {df['Year'].nunique()} years")


# In[11]:


#Data Quality Assessment 
# Quality assessment
print("=" * 80)
print("DATA QUALITY ASSESSMENT")
print("=" * 80)

# Completeness
total_cells = len(df) * len(df.columns)
non_empty_cells = total_cells - df.isnull().sum().sum()
completeness = (non_empty_cells / total_cells) * 100

print(f"\n✓ Data Completeness: {completeness:.2f}%")
print(f"  Total cells: {total_cells:,}")
print(f"  Non-empty cells: {non_empty_cells:,}")
print(f"  Empty cells: {df.isnull().sum().sum():,}")

# Consistency
print(f"\n✓ Duplicate rows: {df.duplicated().sum()}")

# Top missing columns
if df.isnull().sum().sum() > 0:
    print(f"\n✓ Top columns with missing values:")
    top_missing = df.isnull().sum().nlargest(10)
    for col, count in top_missing.items():
        if count > 0:
            pct = (count / len(df)) * 100
            print(f"  - {col:30s}: {count:5d} ({pct:5.1f}%)")

print(f"\n✓ Dataset Size:")
print(f"  - Rows: {len(df):,}")
print(f"  - Columns: {len(df.columns)}")
print(f"  - Memory usage: {df.memory_usage(deep=True).sum() / 1024**2:.2f} MB")

print("\n" + "=" * 80)
print("DATASET UNDERSTANDING COMPLETE")
print("=" * 80)
print("\nKey Insights:")
print(f"• This dataset contains {len(df):,} health and development records")
print(f"• Covering {df['Country'].nunique()} countries from {df['Year'].min()} to {df['Year'].max()}")
print(f"• Target variable: Life expectancy (average: {df['Life expectancy '].mean():.1f} years)")
print(f"• Mix of {len(categorical_cols)} categorical and {len(numerical_cols)} numerical features")


# In[4]:


# Dataset Summary Statistics for Introduction
print("\n" + "=" * 80)
print("DATASET SUMMARY FOR INTRODUCTION")
print("=" * 80)

print("\n DATASET DIMENSIONS")
print(f"   • Total Records: {len(df):,}")
print(f"   • Total Features: {len(df.columns)}")
print(f"   • Target Variable: Life expectancy (continuous, regression problem)")
print(f"   • Time Span: {df['Year'].min()}-{df['Year'].max()} ({df['Year'].max() - df['Year'].min() + 1} years)")
print(f"   • Countries: {df['Country'].nunique()}")

print("\n DEVELOPMENT STATUS DISTRIBUTION")
status_dist = df['Status'].value_counts()
for status, count in status_dist.items():
    pct = (count / len(df)) * 100
    print(f"   • {status:15s}: {count:5d} records ({pct:5.1f}%)")

print("\n TARGET VARIABLE STATISTICS - Life Expectancy")
life_exp = df['Life expectancy '].dropna()
print(f"   • Mean:           {life_exp.mean():6.2f} years")
print(f"   • Median:         {life_exp.median():6.2f} years")
print(f"   • Std Deviation:  {life_exp.std():6.2f} years")
print(f"   • Range:          {life_exp.min():.2f} - {life_exp.max():.2f} years")
print(f"   • Missing Values: {df['Life expectancy '].isnull().sum()}")

print("\n FEATURE STATISTICS")
numerical_features = df.select_dtypes(include=[np.number]).columns.tolist()
numerical_features.remove('Year')  # Remove Year from features list
print(f"   • Numerical Features: {len(numerical_features)}")
print(f"   • Categorical Features: {len(df.select_dtypes(include='object').columns)}")

# Missing values severity
print("\n  DATA QUALITY METRICS")
total_missing = df.isnull().sum().sum()
total_cells = len(df) * len(df.columns)
completeness = ((total_cells - total_missing) / total_cells) * 100
print(f"   • Data Completeness: {completeness:.2f}%")
print(f"   • Total Missing Values: {total_missing:,} out of {total_cells:,} cells")

# Features with missing values
features_with_missing = df.isnull().sum()
features_with_missing = features_with_missing[features_with_missing > 0].sort_values(ascending=False)
if len(features_with_missing) > 0:
    print(f"   • Features with Missing Values: {len(features_with_missing)}")
    print(f"     Top 5 most affected features:")
    for feature, count in features_with_missing.head(5).items():
        pct = (count / len(df)) * 100
        print(f"       - {feature:30s}: {count:5d} ({pct:5.1f}%)")

print("\n" + "=" * 80)


# In[16]:


# Import additional libraries for preprocessing
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.impute import KNNImputer
import copy

print("=" * 80)
print("STEP 1: MISSING VALUE IMPUTATION")
print("=" * 80)

# Create a copy for preprocessing
df_processed = df.copy()

# Identify missing values
missing_summary = df_processed.isnull().sum()
missing_cols = missing_summary[missing_summary > 0].sort_values(ascending=False)

print("\nMissing Values Before Imputation:")
print(missing_cols)

# Step 1: Remove rows where target variable is missing
target_col = 'Life expectancy '
initial_rows = len(df_processed)
df_processed = df_processed[df_processed[target_col].notna()]
print(f"\nRemoved {initial_rows - len(df_processed)} rows with missing target variable")

# Step 2: Impute missing values in numerical columns
numerical_cols_to_impute = df_processed.select_dtypes(include=[np.number]).columns.tolist()
numerical_cols_to_impute.remove('Year')  # Year doesn't need imputation

# Identify columns with missing values
cols_with_missing = [col for col in numerical_cols_to_impute if df_processed[col].isnull().any()]

if len(cols_with_missing) > 0:
    print(f"\nImputing {len(cols_with_missing)} numerical columns...")
    
    # Use KNN imputation with k=5
    imputer = KNNImputer(n_neighbors=5)
    df_processed[cols_with_missing] = imputer.fit_transform(df_processed[cols_with_missing])
    
    print("✓ KNN Imputation completed (k=5)")

# Verify no missing values remain in numerical columns
print("\nMissing Values After Imputation:")
remaining_missing = df_processed[numerical_cols_to_impute].isnull().sum()
print(f"Total missing in numerical columns: {remaining_missing.sum()}")

print("\n" + "=" * 80)
print("STEP 2: OUTLIER ANALYSIS")
print("=" * 80)

# Outlier detection using IQR
print("\nDetecting outliers using IQR method (threshold = 1.5 × IQR)...")

outlier_summary = []
for col in numerical_cols_to_impute:
    Q1 = df_processed[col].quantile(0.25)
    Q3 = df_processed[col].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    
    outliers = df_processed[(df_processed[col] < lower_bound) | (df_processed[col] > upper_bound)]
    if len(outliers) > 0:
        outlier_summary.append({
            'Column': col,
            'Outlier_Count': len(outliers),
            'Percentage': (len(outliers) / len(df_processed)) * 100
        })

if outlier_summary:
    outlier_df = pd.DataFrame(outlier_summary).sort_values('Outlier_Count', ascending=False)
    print("\nColumns with Outliers:")
    print(outlier_df.to_string(index=False))
    print("\n✓ Outliers retained (they represent genuine extreme cases)")
else:
    print("✓ No significant outliers detected")

print("\n" + "=" * 80)
print("STEP 3: FEATURE ENGINEERING")
print("=" * 80)

# Create composite features based on domain knowledge
print("\nCreating composite health metrics...")

# First, let's verify the exact column names to avoid KeyError
print("\nVerifying column names...")
print("Available columns:", df_processed.columns.tolist()[:10], "...")

# 1. Mortality Index - handle column name variations
try:
    df_processed['Mortality_Index'] = (
        df_processed['Adult Mortality'] + 
        df_processed['infant deaths'] + 
        df_processed['under-five deaths']
    ) / 3
    print("✓ Created Mortality_Index")
except KeyError as e:
    print(f"Error creating Mortality_Index: {e}")
    print("Checking available columns with 'Mortality' or 'death':")
    print([col for col in df_processed.columns if 'ortality' in col or 'death' in col.lower()])

# 2. Immunization Rate - handle column name variations
try:
    # Check for exact column names
    immun_cols = []
    if 'Measles ' in df_processed.columns:
        immun_cols.append('Measles ')
    if 'Polio' in df_processed.columns:
        immun_cols.append('Polio')
    if 'Diphtheria ' in df_processed.columns:
        immun_cols.append('Diphtheria ')
    if 'Hepatitis B' in df_processed.columns:
        immun_cols.append('Hepatitis B')
    
    if len(immun_cols) > 0:
        df_processed['Immunization_Rate'] = df_processed[immun_cols].mean(axis=1)
        print(f"✓ Created Immunization_Rate using {len(immun_cols)} columns")
    else:
        print("Warning: Could not find immunization columns")
except Exception as e:
    print(f"Error creating Immunization_Rate: {e}")

# 3. Malnutrition Index - handle column name variations
try:
    malnut_cols = []
    if ' thinness  1-19 years' in df_processed.columns:
        malnut_cols.append(' thinness  1-19 years')
    if ' thinness 5-9 years' in df_processed.columns:
        malnut_cols.append(' thinness 5-9 years')
    
    if len(malnut_cols) == 2:
        df_processed['Malnutrition_Index'] = df_processed[malnut_cols].mean(axis=1)
        print("✓ Created Malnutrition_Index")
    else:
        print("Warning: Could not find thinness columns")
except Exception as e:
    print(f"Error creating Malnutrition_Index: {e}")

# 4. Healthcare Access Index
try:
    df_processed['Healthcare_Access_Index'] = (
        df_processed['Total expenditure'] + 
        df_processed['percentage expenditure']
    ) / 2
    print("✓ Created Healthcare_Access_Index")
except KeyError as e:
    print(f"Error creating Healthcare_Access_Index: {e}")

# 5. Development Score
try:
    df_processed['Development_Score'] = (
        (df_processed['GDP'] / df_processed['GDP'].max()) +
        (df_processed['Income composition of resources']) +
        (df_processed['Schooling'] / df_processed['Schooling'].max())
    ) / 3
    print("✓ Created Development_Score")
except KeyError as e:
    print(f"Error creating Development_Score: {e}")
    print("Checking available columns with 'GDP', 'Income', 'Schooling':")
    print([col for col in df_processed.columns if 'GDP' in col or 'Income' in col or 'Schooling' in col or 'school' in col.lower()])

# Handle any NaN from feature engineering
df_processed = df_processed.fillna(df_processed.mean(numeric_only=True))

print(f"\n✓ Feature engineering completed")
print(f"  Dataset shape: {df_processed.shape}")
print(f"  Total columns: {len(df_processed.columns)}")


# In[21]:


print("\n" + "=" * 80)
print("STEP 4: FEATURE ENCODING AND SCALING")
print("=" * 80)

# Prepare features and target
X = df_processed.copy()
y = X.pop(target_col)

# Identify categorical and numerical columns
categorical_features = X.select_dtypes(include='object').columns.tolist()
numerical_features = X.select_dtypes(include=[np.number]).columns.tolist()

print(f"\nCategorical features: {categorical_features}")
print(f"Numerical features ({len(numerical_features)}): {numerical_features[:5]}... and {len(numerical_features)-5} more")

# Encode categorical variables
print("\nEncoding categorical variables...")

# One-Hot Encode 'Status' (only 2 categories)
X_encoded = pd.get_dummies(X, columns=['Status'], prefix='Status', drop_first=True)

# Label Encode 'Country' (too many categories for one-hot)
le_country = LabelEncoder()
X_encoded['Country_encoded'] = le_country.fit_transform(X_encoded['Country'])
X_encoded = X_encoded.drop('Country', axis=1)

print("✓ Status: One-Hot Encoded (Developed/Developing)")
print(f"✓ Country: Label Encoded ({X_encoded['Country_encoded'].nunique()} unique values)")

# Remove Year if needed for certain models (or keep for temporal features)
print(f"\n✓ Year retained for temporal analysis")

# Scale numerical features (excluding encoded/categorical features)
print("\nScaling numerical features...")
scaler = StandardScaler()
numerical_cols_for_scaling = [col for col in numerical_features if col in X_encoded.columns]
X_encoded[numerical_cols_for_scaling] = scaler.fit_transform(X_encoded[numerical_cols_for_scaling])

print(f"✓ {len(numerical_cols_for_scaling)} numerical features scaled using StandardScaler")

print("\n" + "=" * 80)
print("STEP 5: TRAIN-TEST SPLIT")
print("=" * 80)

# Stratified temporal split (2000-2012: train, 2013-2015: test)
train_years = [year for year in range(2000, 2013)]
test_years = [year for year in range(2013, 2016)]

train_mask = X_encoded['Year'].isin(train_years)
test_mask = X_encoded['Year'].isin(test_years)

X_train = X_encoded[train_mask].copy()
y_train = y[train_mask].copy()
X_test = X_encoded[test_mask].copy()
y_test = y[test_mask].copy()

print(f"\nTrain Set:")
print(f"  • Years: {train_years}")
print(f"  • Samples: {len(X_train):,} ({len(X_train)/len(X_encoded)*100:.1f}%)")
print(f"  • Target mean: {y_train.mean():.2f} years")
print(f"  • Target std: {y_train.std():.2f} years")

print(f"\nTest Set:")
print(f"  • Years: {test_years}")
print(f"  • Samples: {len(X_test):,} ({len(X_test)/len(X_encoded)*100:.1f}%)")
print(f"  • Target mean: {y_test.mean():.2f} years")
print(f"  • Target std: {y_test.std():.2f} years")

# Status distribution check - with robust handling
status_cols = [col for col in X_train.columns if 'Status' in col]

if len(status_cols) > 0:
    print(f"\nStatus Distribution in Train Set:")
    status_col = status_cols[0]  # Use first status column found
    try:
        train_status = X_train[status_col].value_counts().sort_index()
        # Iterate through actual values in the status column
        for status_val in sorted(train_status.index):
            count = train_status[status_val]
            status_name = "Developing" if status_val == 1 else "Developed"
            pct = (count / len(X_train)) * 100
            print(f"  • {status_name}: {count} ({pct:.1f}%)")
    except Exception as e:
        print(f"  • Could not extract status distribution: {e}")
        print(f"  • Available columns: {status_cols}")
else:
    print(f"\n✓ Status encoding complete")

print("\n✓ Train-test split completed with temporal separation")
print("✓ No data leakage: Future data (2013-2015) kept for testing")

print("\n" + "=" * 80)
print("DATA PREPROCESSING COMPLETE")
print("=" * 80)
print(f"\nFinal Dataset Shape:")
print(f"  • X_train: {X_train.shape}")
print(f"  • X_test: {X_test.shape}")
print(f"  • Features: {X_train.shape[1]}")
print(f"  • Ready for model training!")
print("=" * 80)


# In[27]:


# Inspect available years
years = X_encoded['Year'].unique()
print("Available years:", sorted(years))

# Automatically choose split ranges based on min/max year
min_year, max_year = X_encoded['Year'].min(), X_encoded['Year'].max()
print(f"Dataset covers {min_year} → {max_year}")

# Example: use 80% of years for training, last 20% for testing
split_point = int(min_year + 0.8 * (max_year - min_year))

train_mask = X_encoded['Year'] <= split_point
test_mask = X_encoded['Year'] > split_point

X_train = X_encoded[train_mask].copy()
y_train = y[train_mask].copy()
X_test = X_encoded[test_mask].copy()
y_test = y[test_mask].copy()

print("Train shape:", X_train.shape, "Test shape:", X_test.shape)


# In[5]:


# Import ML libraries
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.model_selection import cross_val_score, GridSearchCV
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, mean_absolute_percentage_error

print("=" * 80)
print("MODEL TRAINING: REGRESSION ALGORITHMS")
print("=" * 80)

# Verify that X_train and y_train are available
try:
    print(f"\n✓ X_train shape: {X_train.shape}")
    print(f"✓ y_train shape: {y_train.shape}")
    print(f"✓ X_test shape: {X_test.shape}")
    print(f"✓ y_test shape: {y_test.shape}")
except NameError as e:
    print(f"❌ Error: {e}")
    print("Please run the data preprocessing cell first (encoding/scaling/split).")
    raise

# === Data validation & coercion ===
# Ensure target is numeric and 1-D
y_train = pd.to_numeric(y_train, errors='coerce')
y_test = pd.to_numeric(y_test, errors='coerce')

# Align indices and drop rows where target became NaN
nan_train_mask = y_train.isna()
if nan_train_mask.any():
    print(f"⚠️ {nan_train_mask.sum()} training rows have non-numeric or missing target; dropping them.")
    X_train = X_train.loc[~nan_train_mask].copy()
    y_train = y_train.loc[~nan_train_mask].copy()

nan_test_mask = y_test.isna()
if nan_test_mask.any():
    print(f"⚠️ {nan_test_mask.sum()} test rows have non-numeric or missing target; dropping them.")
    X_test = X_test.loc[~nan_test_mask].copy()
    y_test = y_test.loc[~nan_test_mask].copy()

# Keep only numeric features for sklearn models
numeric_cols_train = X_train.select_dtypes(include=[np.number]).columns.tolist()
non_numeric = [c for c in X_train.columns if c not in numeric_cols_train]
if non_numeric:
    print(f"⚠️ Dropping non-numeric feature columns before training: {non_numeric}")

X_train_num = X_train[numeric_cols_train].copy()
X_test_num = X_test[numeric_cols_train].copy()  # ensure same columns used in test

# Ensure train/test columns match exactly
missing_in_test = [c for c in X_train_num.columns if c not in X_test_num.columns]
if missing_in_test:
    print(f" The following training columns are missing in test and will be dropped for training: {missing_in_test}")
    X_train_num = X_train_num.drop(columns=missing_in_test)
    # Recompute numeric_cols used

# Fill remaining NaNs with column means (should be rare after preprocessing)
if X_train_num.isnull().any().any():
    print(f" Filling {X_train_num.isnull().sum().sum()} NaN(s) in X_train with column means")
    X_train_num = X_train_num.fillna(X_train_num.mean())
if X_test_num.isnull().any().any():
    print(f" Filling {X_test_num.isnull().sum().sum()} NaN(s) in X_test with training column means")
    # Use training means to fill test NaNs to avoid data leakage
    X_test_num = X_test_num.fillna(X_train_num.mean())

# Final shape check
print(f"\nUsing {X_train_num.shape[1]} numeric features for training")

# Convert to arrays (sklearn accepts DataFrame but ensure y is 1d)
X_tr = X_train_num.values
X_te = X_test_num.values
y_tr = np.ravel(y_train.values)
y_te = np.ravel(y_test.values)

# Dictionary to store models and their results
models = {}
cv_results = {}
test_results = {}

print("\n Training multiple regression models...\n")

# 1. LINEAR REGRESSION
print("-" * 80)
print("1. LINEAR REGRESSION (Baseline)")
print("-" * 80)

try:
    lr_model = LinearRegression()
    lr_model.fit(X_tr, y_tr)

    # Cross-validation score
    lr_cv_scores = cross_val_score(lr_model, X_tr, y_tr, cv=5, scoring='r2')
    lr_pred_test = lr_model.predict(X_te)

    cv_results['Linear Regression'] = {
        'cv_mean': lr_cv_scores.mean(),
        'cv_std': lr_cv_scores.std()
    }

    test_results['Linear Regression'] = {
        'MAE': mean_absolute_error(y_te, lr_pred_test),
        'RMSE': np.sqrt(mean_squared_error(y_te, lr_pred_test)),
        'R2': r2_score(y_te, lr_pred_test),
        'MAPE': mean_absolute_percentage_error(y_te, lr_pred_test)
    }

    models['Linear Regression'] = lr_model

    print(f"CV Score (R²): {lr_cv_scores.mean():.4f} ± {lr_cv_scores.std():.4f}")
    print(f"Test R²: {test_results['Linear Regression']['R2']:.4f}")
    print(f"Test MAE: {test_results['Linear Regression']['MAE']:.4f} years")
    print("✓ Model trained and evaluated")
except Exception as e:
    print(f" Error training Linear Regression: {e}")
    import traceback
    traceback.print_exc()
    # Continue to next models but note failure

# 2. RIDGE REGRESSION
print("\n" + "-" * 80)
print("2. RIDGE REGRESSION (L2 Regularization)")
print("-" * 80)

try:
    ridge_model = Ridge(alpha=1.0)
    ridge_model.fit(X_tr, y_tr)

    ridge_cv_scores = cross_val_score(ridge_model, X_tr, y_tr, cv=5, scoring='r2')
    ridge_pred_test = ridge_model.predict(X_te)

    cv_results['Ridge Regression'] = {
        'cv_mean': ridge_cv_scores.mean(),
        'cv_std': ridge_cv_scores.std()
    }

    test_results['Ridge Regression'] = {
        'MAE': mean_absolute_error(y_te, ridge_pred_test),
        'RMSE': np.sqrt(mean_squared_error(y_te, ridge_pred_test)),
        'R2': r2_score(y_te, ridge_pred_test),
        'MAPE': mean_absolute_percentage_error(y_te, ridge_pred_test)
    }

    models['Ridge Regression'] = ridge_model

    print(f"CV Score (R²): {ridge_cv_scores.mean():.4f} ± {ridge_cv_scores.std():.4f}")
    print(f"Test R²: {test_results['Ridge Regression']['R2']:.4f}")
    print(f"Test MAE: {test_results['Ridge Regression']['MAE']:.4f} years")
    print("✓ Model trained and evaluated")
except Exception as e:
    print(f" Error training Ridge Regression: {e}")
    import traceback
    traceback.print_exc()

# 3. DECISION TREE
print("\n" + "-" * 80)
print("3. DECISION TREE REGRESSOR")
print("-" * 80)

try:
    dt_model = DecisionTreeRegressor(max_depth=15, random_state=42, min_samples_split=5)
    dt_model.fit(X_tr, y_tr)

    dt_cv_scores = cross_val_score(dt_model, X_tr, y_tr, cv=5, scoring='r2')
    dt_pred_test = dt_model.predict(X_te)

    cv_results['Decision Tree'] = {
        'cv_mean': dt_cv_scores.mean(),
        'cv_std': dt_cv_scores.std()
    }

    test_results['Decision Tree'] = {
        'MAE': mean_absolute_error(y_te, dt_pred_test),
        'RMSE': np.sqrt(mean_squared_error(y_te, dt_pred_test)),
        'R2': r2_score(y_te, dt_pred_test),
        'MAPE': mean_absolute_percentage_error(y_te, dt_pred_test)
    }

    models['Decision Tree'] = dt_model

    print(f"CV Score (R²): {dt_cv_scores.mean():.4f} ± {dt_cv_scores.std():.4f}")
    print(f"Test R²: {test_results['Decision Tree']['R2']:.4f}")
    print(f"Test MAE: {test_results['Decision Tree']['MAE']:.4f} years")
    print("✓ Model trained and evaluated")
except Exception as e:
    print(f" Error training Decision Tree: {e}")
    import traceback
    traceback.print_exc()

# 4. RANDOM FOREST
print("\n" + "-" * 80)
print("4. RANDOM FOREST REGRESSOR")
print("-" * 80)

try:
    rf_model = RandomForestRegressor(n_estimators=200, max_depth=20, 
                                      min_samples_split=5, min_samples_leaf=2,
                                      random_state=42, n_jobs=-1)
    rf_model.fit(X_tr, y_tr)

    rf_cv_scores = cross_val_score(rf_model, X_tr, y_tr, cv=5, scoring='r2')
    rf_pred_test = rf_model.predict(X_te)

    cv_results['Random Forest'] = {
        'cv_mean': rf_cv_scores.mean(),
        'cv_std': rf_cv_scores.std()
    }

    test_results['Random Forest'] = {
        'MAE': mean_absolute_error(y_te, rf_pred_test),
        'RMSE': np.sqrt(mean_squared_error(y_te, rf_pred_test)),
        'R2': r2_score(y_te, rf_pred_test),
        'MAPE': mean_absolute_percentage_error(y_te, rf_pred_test)
    }

    models['Random Forest'] = rf_model

    print(f"CV Score (R²): {rf_cv_scores.mean():.4f} ± {rf_cv_scores.std():.4f}")
    print(f"Test R²: {test_results['Random Forest']['R2']:.4f}")
    print(f"Test MAE: {test_results['Random Forest']['MAE']:.4f} years")
    print("✓ Model trained and evaluated")
except Exception as e:
    print(f" Error training Random Forest: {e}")
    import traceback
    traceback.print_exc()

# 5. GRADIENT BOOSTING
print("\n" + "-" * 80)
print("5. GRADIENT BOOSTING REGRESSOR")
print("-" * 80)

try:
    gb_model = GradientBoostingRegressor(n_estimators=200, learning_rate=0.1, 
                                          max_depth=5, min_samples_split=5,
                                          random_state=42)
    gb_model.fit(X_tr, y_tr)

    gb_cv_scores = cross_val_score(gb_model, X_tr, y_tr, cv=5, scoring='r2')
    gb_pred_test = gb_model.predict(X_te)

    cv_results['Gradient Boosting'] = {
        'cv_mean': gb_cv_scores.mean(),
        'cv_std': gb_cv_scores.std()
    }

    test_results['Gradient Boosting'] = {
        'MAE': mean_absolute_error(y_te, gb_pred_test),
        'RMSE': np.sqrt(mean_squared_error(y_te, gb_pred_test)),
        'R2': r2_score(y_te, gb_pred_test),
        'MAPE': mean_absolute_percentage_error(y_te, gb_pred_test)
    }

    models['Gradient Boosting'] = gb_model

    print(f"CV Score (R²): {gb_cv_scores.mean():.4f} ± {gb_cv_scores.std():.4f}")
    print(f"Test R²: {test_results['Gradient Boosting']['R2']:.4f}")
    print(f"Test MAE: {test_results['Gradient Boosting']['MAE']:.4f} years")
    print("✓ Model trained and evaluated")
except Exception as e:
    print(f" Error training Gradient Boosting: {e}")
    import traceback
    traceback.print_exc()

# 6. SUPPORT VECTOR MACHINE
print("\n" + "-" * 80)
print("6. SUPPORT VECTOR MACHINE (SVM)")
print("-" * 80)

try:
    svm_model = SVR(kernel='rbf', C=100, gamma='scale', epsilon=0.1)
    svm_model.fit(X_tr, y_tr)

    svm_cv_scores = cross_val_score(svm_model, X_tr, y_tr, cv=5, scoring='r2')
    svm_pred_test = svm_model.predict(X_te)

    cv_results['SVM'] = {
        'cv_mean': svm_cv_scores.mean(),
        'cv_std': svm_cv_scores.std()
    }

    test_results['SVM'] = {
        'MAE': mean_absolute_error(y_te, svm_pred_test),
        'RMSE': np.sqrt(mean_squared_error(y_te, svm_pred_test)),
        'R2': r2_score(y_te, svm_pred_test),
        'MAPE': mean_absolute_percentage_error(y_te, svm_pred_test)
    }

    models['SVM'] = svm_model

    print(f"CV Score (R²): {svm_cv_scores.mean():.4f} ± {svm_cv_scores.std():.4f}")
    print(f"Test R²: {test_results['SVM']['R2']:.4f}")
    print(f"Test MAE: {test_results['SVM']['MAE']:.4f} years")
    print("✓ Model trained and evaluated")
except Exception as e:
    print(f" Error training SVM: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "=" * 80)
print("ALL MODELS TRAINED (attempted)")
print("=" * 80)


# In[30]:


print("\n" + "=" * 80)
print("MODEL PERFORMANCE COMPARISON")
print("=" * 80)

# Create comparison DataFrame
comparison_df = pd.DataFrame({
    'Model': list(test_results.keys()),
    'MAE (years)': [test_results[m]['MAE'] for m in test_results.keys()],
    'RMSE (years)': [test_results[m]['RMSE'] for m in test_results.keys()],
    'R² Score': [test_results[m]['R2'] for m in test_results.keys()],
    'MAPE (%)': [test_results[m]['MAPE'] for m in test_results.keys()],
    'CV Mean (R²)': [cv_results[m]['cv_mean'] for m in test_results.keys()]
})

comparison_df = comparison_df.sort_values('R² Score', ascending=False)

print("\n📊 TEST SET PERFORMANCE METRICS")
print(comparison_df.to_string(index=False))

# Identify best model by different metrics
print("\n" + "-" * 80)
print("BEST MODELS BY METRIC:")
print("-" * 80)
print(f"Best R² Score:  {comparison_df.iloc[0]['Model']} ({comparison_df.iloc[0]['R² Score']:.4f})")
print(f"Best MAE:       {comparison_df.loc[comparison_df['MAE (years)'].idxmin(), 'Model']} ({comparison_df['MAE (years)'].min():.4f} years)")
print(f"Best RMSE:      {comparison_df.loc[comparison_df['RMSE (years)'].idxmin(), 'Model']} ({comparison_df['RMSE (years)'].min():.4f} years)")
print(f"Best MAPE:      {comparison_df.loc[comparison_df['MAPE (%)'].idxmin(), 'Model']} ({comparison_df['MAPE (%)'].min():.2f}%)")

# Select best model
best_model_name = comparison_df.iloc[0]['Model']
best_model = models[best_model_name]

print("\n" + "=" * 80)
print(f"SELECTED MODEL: {best_model_name.upper()}")
print("=" * 80)
print(f"\n✓ Best overall performance with R² = {comparison_df.iloc[0]['R² Score']:.4f}")
print(f"✓ MAE of {comparison_df.iloc[0]['MAE (years)']:.4f} years (average prediction error)")
print(f"✓ RMSE of {comparison_df.iloc[0]['RMSE (years)']:.4f} years")
print(f"✓ Cross-validation score: {cv_results[best_model_name]['cv_mean']:.4f} ± {cv_results[best_model_name]['cv_std']:.4f}")

# Feature importance for tree-based models
if best_model_name in ['Random Forest', 'Gradient Boosting', 'Decision Tree']:
    print(f"\n📊 TOP 10 IMPORTANT FEATURES ({best_model_name}):")
    print("-" * 80)
    
    # Determine the correct feature names used for training
    try:
        feature_names = feature_columns_for_models
    except NameError:
        try:
            feature_names = list(best_model.feature_names_in_)
        except Exception:
            feature_names = list(X_train.columns)

    fi = best_model.feature_importances_
    # Align lengths between feature names and importances
    if len(feature_names) != len(fi):
        print(f"⚠️ Feature name / importance length mismatch: names={len(feature_names)}, importances={len(fi)}")
        if len(feature_names) > len(fi):
            feature_names = feature_names[:len(fi)]
        else:
            feature_names = feature_names + [f"feat_{i}" for i in range(len(feature_names), len(fi))]

    feature_importance = pd.DataFrame({
        'Feature': feature_names,
        'Importance': fi
    }).sort_values('Importance', ascending=False)
    
    print(feature_importance.head(10).to_string(index=False))
    
    # Calculate cumulative importance
    cum_importance = feature_importance['Importance'].cumsum() / feature_importance['Importance'].sum()
    top_5_importance = cum_importance.iloc[4] if len(cum_importance) > 4 else cum_importance.iloc[-1]
    top_10_importance = cum_importance.iloc[9] if len(cum_importance) > 9 else cum_importance.iloc[-1]
    
    print(f"\n✓ Top 5 features explain {top_5_importance*100:.1f}% of variance")
    print(f"✓ Top 10 features explain {top_10_importance*100:.1f}% of variance")


# In[31]:


print("\n" + "=" * 80)
print("KEY FINDINGS AND INSIGHTS")
print("=" * 80)

print("\n1️⃣  MODEL RANKINGS BY R² SCORE:")
print("-" * 80)
for idx, (_, row) in enumerate(comparison_df.iterrows(), 1):
    print(f"{idx}. {row['Model']:25s} R² = {row['R² Score']:.4f}, MAE = {row['MAE (years)']:.2f} years")

print("\n2️⃣  BEST MODEL CHARACTERISTICS:")
print("-" * 80)
best_row = comparison_df.iloc[0]
print(f"Model: {best_row['Model']}")
print(f"  • Explains {best_row['R² Score']*100:.2f}% of life expectancy variance")
print(f"  • Average prediction error: ±{best_row['MAE (years)']:.2f} years")
print(f"  • Standard deviation of errors: {best_row['RMSE (years)']:.2f} years")
print(f"  • Relative error: {best_row['MAPE (%)']:.2f}%")
print(f"  • Cross-validation R²: {best_row['CV Mean (R²)']:.4f}")

print("\n3️⃣  MODEL COMPARISON INSIGHTS:")
print("-" * 80)
print(f"Best Linear Model: {comparison_df[comparison_df['Model'].str.contains('Linear|Ridge')].iloc[0]['Model']}")
print(f"  → Linear relationships exist but non-linear models perform better")

print(f"\nBest Tree Model: {comparison_df[comparison_df['Model'].str.contains('Tree|Forest|Gradient')].iloc[0]['Model']}")
print(f"  → Captures complex interactions between features")

improvement = ((comparison_df.iloc[0]['R² Score'] - comparison_df.iloc[-1]['R² Score']) / comparison_df.iloc[-1]['R² Score'] * 100)
print(f"\nImprovement (Best vs Worst): {improvement:.2f}%")

print("\n" + "=" * 80)
print("DEPLOYMENT RECOMMENDATION")
print("=" * 80)
print(f"\n✅ RECOMMENDED MODEL: {best_model_name}")
print(f"\nWhy this model:")
print(f"  • Highest R² score ({comparison_df.iloc[0]['R² Score']:.4f})")
print(f"  • Low prediction error ({comparison_df.iloc[0]['MAE (years)']:.2f} years on average)")
print(f"  • Consistent cross-validation performance")
if best_model_name in ['Random Forest', 'Gradient Boosting']:
    print(f"  • Robust to outliers and feature scaling")
    print(f"  • Interpretable feature importance rankings")
print(f"  • Suitable for real-world deployment")

print("\n" + "=" * 80)
print("REPORT GENERATION COMPLETE")
print("=" * 80)


# In[32]:


# Target distribution and basic EDA plots
try:
    target = 'Life expectancy '
    plt.figure(figsize=(12,5))
    sns.histplot(df[target].dropna(), kde=True, bins=30, color='C0')
    plt.title('Distribution of Life Expectancy')
    plt.xlabel('Life expectancy (years)')
    plt.ylabel('Count')
    plt.show()

    # Boxplot by Status (if present)
    if 'Status' in df.columns:
        plt.figure(figsize=(10,5))
        sns.boxplot(x='Status', y=target, data=df)
        plt.title('Life Expectancy by Development Status')
        plt.show()

    # Top 10 countries by mean life expectancy (sample)
    mean_by_country = df.groupby('Country')[target].mean().dropna().sort_values(ascending=False).head(10)
    plt.figure(figsize=(12,5))
    sns.barplot(x=mean_by_country.values, y=mean_by_country.index, palette='viridis')
    plt.title('Top 10 Countries by Mean Life Expectancy')
    plt.xlabel('Mean Life Expectancy (years)')
    plt.ylabel('Country')
    plt.show()
except Exception as e:
    print('Could not produce basic EDA plots — make sure `df` is loaded. Error: ', e)


# In[33]:


# Correlation heatmap for numeric features
try:
    # Prefer df_processed if available (post-imputation/feature-engineering), else use df
    corr_df = df_processed.select_dtypes(include=[np.number]) if 'df_processed' in globals() else df.select_dtypes(include=[np.number])
    corr = corr_df.corr()
    plt.figure(figsize=(14,12))
    sns.heatmap(corr, cmap='coolwarm', center=0, vmax=1.0, vmin=-1.0, fmt='.2f')
    plt.title('Correlation matrix (numeric features)')
    plt.show()
except Exception as e:
    print('Could not produce correlation heatmap — ensure `df_processed` or `df` is present. Error: ', e)


# In[34]:


# Model comparison bar chart (MAE / RMSE / R2)
try:
    # comparison_df should exist after model evaluation
    plot_df = comparison_df.copy()
    # Normalize metrics for side-by-side plotting where needed
    plt.figure(figsize=(12,6))
    sns.barplot(x='R² Score', y='Model', data=plot_df, palette='magma')
    plt.title('Model Comparison — R² on Test Set')
    plt.xlabel('R² Score')
    plt.xlim(0, 1)
    plt.show()

    plt.figure(figsize=(12,6))
    sns.barplot(x='MAE (years)', y='Model', data=plot_df, palette='crest')
    plt.title('Model Comparison — MAE on Test Set (years)')
    plt.xlabel('MAE (years)')
    plt.show()
except Exception as e:
    print('Could not plot model comparison — ensure `comparison_df` exists. Error:', e)


# In[35]:


# Feature importance / coefficients for best model
try:
    # Prefer the computed `feature_importance` DataFrame if present (from evaluation cell)
    if 'feature_importance' in globals():
        fi_df = feature_importance.copy()
    else:
        # Attempt to compute from best_model if it's tree-based or linear
        if best_model_name in ['Random Forest', 'Gradient Boosting', 'Decision Tree'] and hasattr(best_model, 'feature_importances_'):
            names = feature_columns_for_models if 'feature_columns_for_models' in globals() else (list(X_train.columns) if 'X_train' in globals() else None)
            fi_df = pd.DataFrame({'Feature': names, 'Importance': best_model.feature_importances_})
        elif best_model_name in ['Linear Regression', 'Ridge'] and hasattr(best_model, 'coef_'):
            names = feature_columns_for_models if 'feature_columns_for_models' in globals() else (list(X_train.columns) if 'X_train' in globals() else None)
            fi_df = pd.DataFrame({'Feature': names, 'Coefficient': best_model.coef_})
            fi_df['Importance'] = fi_df['Coefficient'].abs()
        else:
            raise ValueError('Best model does not expose importances or coefficients in a supported way.')

    fi_df = fi_df.sort_values('Importance', ascending=False).head(20)
    plt.figure(figsize=(10,8))
    sns.barplot(x='Importance', y='Feature', data=fi_df, palette='viridis')
    plt.title(f'Top Features — {best_model_name}')
    plt.xlabel('Importance (absolute)')
    plt.tight_layout()
    plt.show()
except Exception as e:
    print('Could not plot feature importance — ensure models ran and `best_model` exists. Error:', e)


# In[36]:


#  Predicted vs Actual and residual diagnostics for best model
try:
    # Predict on test set and plot
    if 'best_model' not in globals():
        raise ValueError('`best_model` is not available. Run model training first.')
    # Use X_te / y_te or X_test / y_test depending on naming
    X_test_for_pred = X_te if 'X_te' in globals() else (X_test_num if 'X_test_num' in globals() else (X_test if 'X_test' in globals() else None))
    y_test_for_pred = y_te if 'y_te' in globals() else (y_test if 'y_test' in globals() else None)
    if X_test_for_pred is None or y_test_for_pred is None:
        raise ValueError('Test features/target not found (X_te/y_te or X_test/y_test)')

    y_pred = best_model.predict(X_test_for_pred)
    plt.figure(figsize=(8,8))
    sns.scatterplot(x=y_test_for_pred, y=y_pred, alpha=0.6)
    plt.plot([y_test_for_pred.min(), y_test_for_pred.max()], [y_test_for_pred.min(), y_test_for_pred.max()], 'r--')
    plt.xlabel('Actual Life Expectancy')
    plt.ylabel('Predicted Life Expectancy')
    plt.title(f'Predicted vs Actual — {best_model_name}')
    plt.show()

    # Residuals
    residuals = y_test_for_pred - y_pred
    plt.figure(figsize=(10,4))
    sns.histplot(residuals, kde=True, color='C3')
    plt.title('Residual Distribution (Actual - Predicted)')
    plt.xlabel('Residual (years)')
    plt.show()

    plt.figure(figsize=(10,4))
    sns.scatterplot(x=y_pred, y=residuals, alpha=0.6)
    plt.axhline(0, color='r', linestyle='--')
    plt.xlabel('Predicted Life Expectancy')
    plt.ylabel('Residual (Actual - Predicted)')
    plt.title('Residuals vs Predicted')
    plt.show()
except Exception as e:
    print('Could not produce prediction diagnostics — ensure models and test sets are available. Error:', e)


# In[37]:


# Per-model predicted vs actual and residuals
try:
    if 'models' not in globals():
        raise ValueError('`models` dictionary not found. Run model training first.')
    # Determine test arrays to use
    X_test_pred = X_te if 'X_te' in globals() else (X_test_num if 'X_test_num' in globals() else (X_test if 'X_test' in globals() else None))
    y_test_pred = y_te if 'y_te' in globals() else (y_test if 'y_test' in globals() else None)
    if X_test_pred is None or y_test_pred is None:
        raise ValueError('Test set not found (X_te/y_te or X_test/y_test). Run preprocessing and model training.')

    preds_df = pd.DataFrame({'Actual': y_test_pred})
    errors = {}
    for name, model in models.items():
        try:
            yhat = model.predict(X_test_pred)
            preds_df[f'Pred_{name}'] = yhat
            errs = y_test_pred - yhat
            errors[name] = errs
        except Exception as e:
            print(f'Could not generate predictions for model {name}:', e)

    # Plot predicted vs actual for each model in a grid
    n_models = len(models)
    ncols = 2
    nrows = (n_models + ncols - 1) // ncols
    plt.figure(figsize=(12, 4 * nrows))
    for i, name in enumerate(models.keys(), 1):
        plt.subplot(nrows, ncols, i)
        if f'Pred_{name}' in preds_df.columns:
            sns.scatterplot(x=preds_df['Actual'], y=preds_df[f'Pred_{name}'], alpha=0.5)
            mn = min(preds_df['Actual'].min(), preds_df[f'Pred_{name}'].min())
            mx = max(preds_df['Actual'].max(), preds_df[f'Pred_{name}'].max())
            plt.plot([mn, mx], [mn, mx], 'r--')
            plt.title(f'Predicted vs Actual — {name}')
            plt.xlabel('Actual')
            plt.ylabel('Predicted')
        else:
            plt.text(0.5, 0.5, f'No predictions for {name}', ha='center')
    plt.tight_layout()
    plt.show()

    # Residual distribution across models
    plt.figure(figsize=(12,6))
    for name, errs in errors.items():
        sns.kdeplot(errs, label=name, fill=False, alpha=0.6)
    plt.axvline(0, color='k', linestyle='--')
    plt.title('Residual Distribution by Model (Actual - Predicted)')
    plt.xlabel('Residual (years)')
    plt.legend()
    plt.show()

    # Boxplot of absolute errors to compare spread
    abs_errs = pd.DataFrame({name: np.abs(errs) for name, errs in errors.items()})
    plt.figure(figsize=(12,6))
    sns.boxplot(data=abs_errs, orient='h')
    plt.title('Absolute Error Distribution by Model (boxplot)')
    plt.xlabel('Absolute Error (years)')
    plt.show()

except Exception as e:
    print('Per-model diagnostics could not be produced:', e)


# In[6]:


# Feature importance / coefficients for each model (when available)
try:
    if 'models' not in globals():
        raise ValueError('`models` not available. Run model training first.')
    for name, model in models.items():
        try:
            print('\n' + '='*60)
            print(f'Model: {name}')
            # Determine feature names used for training
            feat_names = feature_columns_for_models if 'feature_columns_for_models' in globals() else (list(X_train.columns) if 'X_train' in globals() else None)
            if feat_names is None:
                print('Feature names not available for importance plot')
                continue
            if hasattr(model, 'feature_importances_'):
                fi = np.asarray(model.feature_importances_)
                # Align feature names length to importances length
                n = len(fi)
                if len(feat_names) != n:
                    print(f" Feature name / importance length mismatch for {name}: names={len(feat_names)}, importances={n} — aligning lists")
                    if len(feat_names) > n:
                        feat_names_aligned = feat_names[:n]
                    else:
                        feat_names_aligned = feat_names + [f"feat_{i}" for i in range(len(feat_names), n)]
                else:
                    feat_names_aligned = feat_names
                fi_df = pd.DataFrame({'Feature': feat_names_aligned, 'Importance': fi}).sort_values('Importance', ascending=False).head(20)
                plt.figure(figsize=(8,6))
                sns.barplot(x='Importance', y='Feature', data=fi_df, palette='rocket')
                plt.title(f'Top Features — {name}')
                plt.tight_layout()
                plt.show()
            elif hasattr(model, 'coef_'):
                coefs = np.ravel(model.coef_)
                m = len(coefs)
                if len(feat_names) != m:
                    print(f" Feature name / coefficient length mismatch for {name}: names={len(feat_names)}, coefficients={m} — aligning lists")
                    if len(feat_names) > m:
                        feat_names_aligned = feat_names[:m]
                    else:
                        feat_names_aligned = feat_names + [f"feat_{i}" for i in range(len(feat_names), m)]
                else:
                    feat_names_aligned = feat_names
                coef_df = pd.DataFrame({'Feature': feat_names_aligned, 'Coef': coefs})
                coef_df['Importance'] = coef_df['Coef'].abs()
                coef_df = coef_df.sort_values('Importance', ascending=False).head(20)
                plt.figure(figsize=(8,6))
                sns.barplot(x='Importance', y='Feature', data=coef_df, palette='vlag')
                plt.title(f'Top Coefficients (abs) — {name}')
                plt.tight_layout()
                plt.show()
            else:
                print('No feature importances or coefficients available for this model')
        except Exception as e:
            print(f'Could not compute feature importance for {name}:', e)
except Exception as e:
    print('Feature importance plotting failed:', e)


# In[41]:


# 9.1 Numeric summary of best model and top features
try:
    print('\n=== Numeric Summary of Best Model ===\n')
    if 'comparison_df' in globals() and 'best_model_name' in globals():
        top_row = comparison_df[comparison_df['Model'] == best_model_name].iloc[0]
        print(f"Best model (selected): {best_model_name}")
        print(f"Test R²: {top_row['R² Score']:.4f}")
        print(f"Test MAE (years): {top_row['MAE (years)']:.4f}")
        print(f"Test RMSE (years): {top_row['RMSE (years)']:.4f}")
        print(f"Test MAPE (%): {top_row['MAPE (%)']:.2f}")
    else:
        print('comparison_df or best_model_name not found — run model evaluation cell first')

    # Top features (if available)
    if 'feature_importance' in globals():
        print('\nTop features (from computed importance):')
        display(feature_importance.head(10))
    else:
        # Try to compute from best_model if it's tree-based or linear
        if 'best_model' in globals():
            try:
                if hasattr(best_model, 'feature_importances_'):
                    names = feature_columns_for_models if 'feature_columns_for_models' in globals() else list(X_train.columns)
                    fi = best_model.feature_importances_
                    fi_df = pd.DataFrame({'Feature': names, 'Importance': fi}).sort_values('Importance', ascending=False).head(10)
                    print('\nTop features (computed from best_model.feature_importances_):')
                    display(fi_df)
                elif hasattr(best_model, 'coef_'):
                    names = feature_columns_for_models if 'feature_columns_for_models' in globals() else list(X_train.columns)
                    coef = np.ravel(best_model.coef_)
                    coef_df = pd.DataFrame({'Feature': names, 'Coef': coef})
                    coef_df['Importance'] = coef_df['Coef'].abs()
                    coef_df = coef_df.sort_values('Importance', ascending=False).head(10)
                    print('\nTop features (computed from best_model.coef_):')
                    display(coef_df)
                else:
                    print('\nBest model does not expose importances or coefficients to compute top features')
            except Exception as e:
                print('Could not compute top features from best_model:', e)
        else:
            print('\nNo best_model available — run model training first')
except Exception as e:
    print('Summary cell failed:', e)


# In[ ]:




